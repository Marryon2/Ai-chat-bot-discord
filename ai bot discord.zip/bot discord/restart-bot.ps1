$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $projectPath "data\\bot.pid"

if (Test-Path $pidFile) {
  $botPid = Get-Content $pidFile | Select-Object -First 1
  if ($botPid) {
    Stop-Process -Id ([int]$botPid) -Force -ErrorAction SilentlyContinue
  }
}

Start-Sleep -Milliseconds 500

Set-Location $projectPath
npm.cmd start
