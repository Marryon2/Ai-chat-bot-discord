const path = require("node:path");
const dotenv = require("dotenv");

dotenv.config();

function requireEnv(name) {
  const value = process.env[name];

  if (!value || !value.trim()) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value.trim();
}

function readNumber(name, fallback) {
  const rawValue = process.env[name];

  if (!rawValue) {
    return fallback;
  }

  const value = Number.parseInt(rawValue, 10);

  if (Number.isNaN(value) || value <= 0) {
    throw new Error(`Environment variable ${name} must be a positive integer.`);
  }

  return value;
}

module.exports = {
  discord: {
    token: requireEnv("DISCORD_BOT_TOKEN"),
    applicationId: requireEnv("DISCORD_APPLICATION_ID"),
    guildId: requireEnv("DISCORD_GUILD_ID"),
    startChannelId: requireEnv("DISCORD_START_CHANNEL_ID"),
    allowedRoleId: requireEnv("DISCORD_ALLOWED_ROLE_ID"),
  },
  ai: {
    apiKey: requireEnv("OPENROUTER_API_KEY"),
    model: process.env.OPENROUTER_MODEL?.trim() || "openrouter/free",
    siteUrl: process.env.OPENROUTER_SITE_URL?.trim() || "https://openrouter.ai/",
    systemPrompt:
      process.env.SYSTEM_PROMPT?.trim() ||
      "You are a helpful AI assistant on a Discord server. Respond clearly, briefly, and safely.",
    maxContextMessages: readNumber("MAX_CONTEXT_MESSAGES", 12),
  },
  limits: {
    dailyMessageLimit: readNumber("DAILY_MESSAGE_LIMIT", 15),
  },
  threads: {
    autoArchiveMinutes: readNumber("THREAD_AUTO_ARCHIVE_MINUTES", 1440),
  },
  storage: {
    dataDir: path.join(process.cwd(), "data"),
    usageFile: path.join(process.cwd(), "data", "usage.json"),
    pidFile: path.join(process.cwd(), "data", "bot.pid"),
  },
};
