const fs = require("node:fs");
const {
  ChannelType,
  Client,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  REST,
  Routes,
} = require("discord.js");
const config = require("./config");
const { AIService } = require("./services/ai");
const { moderateInput } = require("./services/moderation");
const { UsageStore } = require("./services/usageStore");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

const usageStore = new UsageStore(config.storage.usageFile);
const aiService = new AIService(config.ai);

function writePidFile() {
  fs.mkdirSync(config.storage.dataDir, { recursive: true });
  fs.writeFileSync(config.storage.pidFile, `${process.pid}\n`, "utf8");
}

function removePidFile() {
  if (fs.existsSync(config.storage.pidFile)) {
    fs.unlinkSync(config.storage.pidFile);
  }
}

function isAdmin(member) {
  return member.permissions.has(PermissionFlagsBits.Administrator);
}

function hasAccess(member) {
  return isAdmin(member) || member.roles.cache.has(config.discord.allowedRoleId);
}

function isManagedAiThread(channel) {
  return (
    channel?.type === ChannelType.PrivateThread &&
    channel.parentId === config.discord.startChannelId
  );
}

async function ensureCommandsRegistered() {
  const rest = new REST({ version: "10" }).setToken(config.discord.token);
  const commands = [
    {
      name: "start-ai",
      description: "Creates a private thread for chatting with the AI.",
    },
    {
      name: "limit",
      description: "Shows how much of your daily limit you have used.",
    },
    {
      name: "end-chat",
      description: "Deletes the current private AI thread.",
    },
    {
      name: "admin-usage",
      description: "Shows today's AI usage across the server.",
    },
  ];

  await rest.put(
    Routes.applicationGuildCommands(config.discord.applicationId, config.discord.guildId),
    { body: commands },
  );
}

async function findExistingThreadForUser(startChannel, userId) {
  const activeThreads = await startChannel.threads.fetchActive();

  return activeThreads.threads.find(
    (thread) =>
      thread.type === ChannelType.PrivateThread &&
      thread.ownerId === client.user.id &&
      thread.name.startsWith(`${userId}-`),
  );
}

async function createPrivateAiThread(interaction) {
  const startChannel = interaction.channel;

  if (startChannel.id !== config.discord.startChannelId) {
    await interaction.reply({
      content: `Use this command only in the start channel: <#${config.discord.startChannelId}>.`,
      ephemeral: true,
    });
    return;
  }

  const existingThread = await findExistingThreadForUser(startChannel, interaction.user.id);

  if (existingThread) {
    await interaction.reply({
      content: `You already have an active thread: <#${existingThread.id}>`,
      ephemeral: true,
    });
    return;
  }

  const thread = await startChannel.threads.create({
    name: `${interaction.user.id}-${interaction.user.username}`.slice(0, 100),
    type: ChannelType.PrivateThread,
    invitable: false,
    autoArchiveDuration: config.threads.autoArchiveMinutes,
    reason: `Private AI chat for ${interaction.user.tag}`,
  });

  await thread.members.add(interaction.user.id);

  await thread.send(
    [
      `Hello <@${interaction.user.id}>.`,
      "This is your private AI thread. Send a message normally and the bot will reply automatically.",
      `Your daily AI message limit is **${config.limits.dailyMessageLimit}**.`,
      "Use `/end-chat` when you want to delete this thread.",
    ].join("\n"),
  );

  await interaction.reply({
    content: `I created your private thread: <#${thread.id}>`,
    ephemeral: true,
  });
}

async function handleLimitCommand(interaction) {
  const used = usageStore.getUsage(interaction.user.id);

  await interaction.reply({
    content: `You have used **${used}/${config.limits.dailyMessageLimit}** AI messages today.`,
    ephemeral: true,
  });
}

async function handleAdminUsage(interaction) {
  if (!isAdmin(interaction.member)) {
    await interaction.reply({
      content: "This command is available to administrators only.",
      ephemeral: true,
    });
    return;
  }

  const summary = usageStore.getTodaySummary();
  const rows = Object.entries(summary.usage);

  if (rows.length === 0) {
    await interaction.reply({
      content: `No usage has been recorded for ${summary.date}.`,
      ephemeral: true,
    });
    return;
  }

  const content = rows
    .sort((left, right) => right[1] - left[1])
    .map(([userId, count]) => `<@${userId}>: ${count}/${config.limits.dailyMessageLimit}`)
    .join("\n");

  await interaction.reply({
    content: `Usage for ${summary.date}:\n${content}`,
    ephemeral: true,
  });
}

async function handleEndChat(interaction) {
  if (!isManagedAiThread(interaction.channel)) {
    await interaction.reply({
      content: "This command only works inside a private AI thread.",
      ephemeral: true,
    });
    return;
  }

  await interaction.reply({
    content: "Deleting this thread.",
    ephemeral: true,
  });

  await interaction.channel.delete("Deleted with /end-chat");
}

async function buildContextMessages(thread, newestUserMessage) {
  const fetchedMessages = await thread.messages.fetch({ limit: config.ai.maxContextMessages });

  return [...fetchedMessages.values()]
    .sort((left, right) => left.createdTimestamp - right.createdTimestamp)
    .filter((message) => !message.system)
    .filter((message) => message.id !== newestUserMessage.id)
    .map((message) => ({
      role: message.author.bot ? "assistant" : "user",
      content: message.content,
    }))
    .concat({
      role: "user",
      content: newestUserMessage.content,
    });
}

async function handleAiMessage(message) {
  if (message.author.bot || !isManagedAiThread(message.channel)) {
    return;
  }

  const member = message.member;

  if (!member) {
    await message.reply("I could not read your permissions on this server.");
    return;
  }

  if (!hasAccess(member)) {
    await message.reply("You do not have the required role to use this bot.");
    return;
  }

  const moderation = moderateInput(message.content);

  if (!moderation.allowed) {
    await message.reply(moderation.reason);
    return;
  }

  const currentUsage = usageStore.getUsage(message.author.id);

  if (currentUsage >= config.limits.dailyMessageLimit) {
    await message.reply(
      `You have reached today's limit of ${config.limits.dailyMessageLimit} messages. Please try again tomorrow.`,
    );
    return;
  }

  await message.channel.sendTyping();

  try {
    const contextMessages = await buildContextMessages(message.channel, message);
    const reply = await aiService.generateReply(contextMessages);

    usageStore.increment(message.author.id);
    await message.reply(reply.slice(0, 1900));
  } catch (error) {
    console.error("Failed to generate AI reply:", error);
    await message.reply(
      "I could not get a response from the model right now. Please try again in a moment.",
    );
  }
}

client.once("ready", async (readyClient) => {
  writePidFile();
  console.log(`Logged in as ${readyClient.user.tag}`);

  try {
    await ensureCommandsRegistered();
    console.log("Commands synced on startup.");
  } catch (error) {
    console.error("Failed to sync commands on startup:", error);
  }
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand() || !interaction.inGuild()) {
    return;
  }

  const member = interaction.member;

  if (!hasAccess(member) && !["admin-usage"].includes(interaction.commandName)) {
    await interaction.reply({
      content: "You do not have access to this bot.",
      ephemeral: true,
    });
    return;
  }

  try {
    if (interaction.commandName === "start-ai") {
      await createPrivateAiThread(interaction);
      return;
    }

    if (interaction.commandName === "limit") {
      await handleLimitCommand(interaction);
      return;
    }

    if (interaction.commandName === "end-chat") {
      await handleEndChat(interaction);
      return;
    }

    if (interaction.commandName === "admin-usage") {
      await handleAdminUsage(interaction);
    }
  } catch (error) {
    console.error("Interaction handler failed:", error);

    const errorMessage = {
      content: "An error occurred while running this command.",
      ephemeral: true,
    };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage);
      return;
    }

    await interaction.reply(errorMessage);
  }
});

client.on("messageCreate", async (message) => {
  await handleAiMessage(message);
});

client.login(config.discord.token).catch((error) => {
  console.error("Discord login failed:", error);
  process.exitCode = 1;
});

process.on("exit", removePidFile);
process.on("SIGINT", () => {
  removePidFile();
  process.exit(0);
});
process.on("SIGTERM", () => {
  removePidFile();
  process.exit(0);
});
