const { REST, Routes, SlashCommandBuilder } = require("discord.js");
const config = require("./config");

const commands = [
  new SlashCommandBuilder()
    .setName("start-ai")
    .setDescription("Creates a private thread for chatting with the AI."),
  new SlashCommandBuilder()
    .setName("limit")
    .setDescription("Shows how much of your daily limit you have used."),
  new SlashCommandBuilder()
    .setName("end-chat")
    .setDescription("Deletes the current private AI thread."),
  new SlashCommandBuilder()
    .setName("admin-usage")
    .setDescription("Shows today's AI usage across the server."),
].map((command) => command.toJSON());

async function main() {
  const rest = new REST({ version: "10" }).setToken(config.discord.token);

  await rest.put(
    Routes.applicationGuildCommands(config.discord.applicationId, config.discord.guildId),
    { body: commands },
  );

  console.log("Guild slash commands registered successfully.");
}

main().catch((error) => {
  console.error("Failed to register commands:", error);
  process.exitCode = 1;
});
