const blockedPatterns = [
  /\b(nsfw|nudes?|nago[sc]?[ci]?|porn|seks|sex|erotic|fetish)\b/i,
  /\b(kill|murder|bomb|terror|napalm|grenade|explosive|wybuch|bomba)\b/i,
  /\b(self[- ]?harm|suicide|samoboj|okaleczan)\b/i,
  /\b(meth|cocaine|heroin|fentanyl|narkotyk|drug lab)\b/i,
  /\b(hack|malware|ransomware|phishing|keylogger)\b/i,
];

function moderateInput(text) {
  const normalized = text.trim();

  if (!normalized) {
    return {
      allowed: false,
      reason: "Please send a normal message instead of an empty prompt.",
    };
  }

  if (normalized.length > 2_000) {
    return {
      allowed: false,
      reason: "Your message is too long. Please keep it under 2000 characters.",
    };
  }

  const matchedPattern = blockedPatterns.find((pattern) => pattern.test(normalized));

  if (matchedPattern) {
    return {
      allowed: false,
      reason: "This request falls under the bot's safety restrictions. Try asking about a neutral, safe topic instead.",
    };
  }

  return { allowed: true, reason: null };
}

module.exports = {
  moderateInput,
};
