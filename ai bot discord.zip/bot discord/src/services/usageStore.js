const fs = require("node:fs");
const path = require("node:path");

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

class UsageStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.state = this.load();
  }

  ensureDirectory() {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
  }

  load() {
    this.ensureDirectory();

    if (!fs.existsSync(this.filePath)) {
      return { byDate: {} };
    }

    try {
      return JSON.parse(fs.readFileSync(this.filePath, "utf8"));
    } catch (error) {
      console.warn("Usage file was invalid, starting fresh.", error);
      return { byDate: {} };
    }
  }

  save() {
    this.ensureDirectory();
    fs.writeFileSync(this.filePath, JSON.stringify(this.state, null, 2), "utf8");
  }

  ensureToday() {
    const today = getTodayKey();

    if (!this.state.byDate[today]) {
      this.state.byDate = { [today]: {} };
    } else {
      this.state.byDate = { [today]: this.state.byDate[today] };
    }

    return today;
  }

  getUsage(userId) {
    const today = this.ensureToday();
    return this.state.byDate[today][userId] ?? 0;
  }

  increment(userId) {
    const today = this.ensureToday();
    const currentValue = this.state.byDate[today][userId] ?? 0;
    const nextValue = currentValue + 1;

    this.state.byDate[today][userId] = nextValue;
    this.save();

    return nextValue;
  }

  getTodaySummary() {
    const today = this.ensureToday();
    return { date: today, usage: { ...this.state.byDate[today] } };
  }
}

module.exports = {
  UsageStore,
};

