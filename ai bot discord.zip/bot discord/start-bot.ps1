$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $projectPath "data\\bot.pid"

if (Test-Path $pidFile) {
  $botPid = Get-Content $pidFile | Select-Object -First 1
  if ($botPid) {
    $existingProcess = Get-Process -Id ([int]$botPid) -ErrorAction SilentlyContinue
    if ($existingProcess) {
      Write-Output "Bot is already running with PID $botPid."
      exit 0
    }
  }
}

Set-Location $projectPath
npm.cmd start
