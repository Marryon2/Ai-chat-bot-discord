$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = Join-Path $projectPath "data\\bot.pid"

if (-not (Test-Path $pidFile)) {
  Write-Output "PID file not found. Bot is probably not running."
  exit 0
}

$botPid = Get-Content $pidFile | Select-Object -First 1

if (-not $botPid) {
  Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
  Write-Output "PID file was empty and has been removed."
  exit 0
}

$existingProcess = Get-Process -Id ([int]$botPid) -ErrorAction SilentlyContinue

if ($existingProcess) {
  Stop-Process -Id ([int]$botPid) -Force
  Start-Sleep -Milliseconds 500
}

Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
Write-Output "Bot stopped."
